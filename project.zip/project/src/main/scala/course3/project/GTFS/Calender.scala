package com.mcit.scala.GTFS

///
//  Created by Dhrumil on 2020-02-06
//

case class Calender(service_id:String,monday:String,tuesday:String,wednesday:String,thursday:String,friday:String,saturday:String,sunday:String,start_date:String,end_date:String)
