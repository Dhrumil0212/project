package com.mcit.scala.GTFS

//
//  Created by Dhrumil on 2020-02-06
//

case class EnrichedTrip(tripRoute: TripRoute, calender: Calender)
