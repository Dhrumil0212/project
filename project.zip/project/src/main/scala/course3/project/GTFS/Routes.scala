package com.mcit.scala.GTFS

//
//  Created by Dhrumil on 2020-02-06
//

case class Routes(route_id: Int,agency_id: String,route_short_name: String,route_long_name: String,route_type: String,route_url: String,route_color: String)
